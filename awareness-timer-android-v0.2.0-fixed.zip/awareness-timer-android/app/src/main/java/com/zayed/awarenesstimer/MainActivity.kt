package com.zayed.awarenesstimer

import android.Manifest
import android.app.AlarmManager
import android.app.DatePickerDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.roundToLong

class MainActivity : AppCompatActivity() {
    private lateinit var root: LinearLayout
    private lateinit var content: LinearLayout

    private var remainingText: TextView? = null
    private var manualTimerText: TextView? = null
    private var longTimerText: TextView? = null
    private var thoughtTimerText: TextView? = null
    private var reportBody: LinearLayout? = null
    private var reportStart: Long = startOfToday()
    private var reportEnd: Long = reportStart + DAY

    private val handler = Handler(Looper.getMainLooper())
    private val ticker = object : Runnable {
        override fun run() {
            refreshLiveTimers()
            handler.postDelayed(this, 1000)
        }
    }

    private val counters = listOf(
        "pre" to "Pre-Do",
        "intra" to "Intra-Do",
        "after" to "After-Do",
        "sessions" to "الجلسات"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestNotificationPermission()
        buildShell()
        showCountersPage()
        handleReminderIntent(intent)
        handleManualAlarmIntent(intent)
        handler.post(ticker)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleReminderIntent(intent)
        handleManualAlarmIntent(intent)
    }

    private fun handleReminderIntent(intent: Intent?) {
        if (intent?.getBooleanExtra("fromReminder", false) != true) return
        val reminderAt = intent.getLongExtra("reminderAt", Prefs.lastReminderAt(this))
        val now = System.currentTimeMillis()
        if (reminderAt > 0L) {
            EventStore.log(this, "reminder_opened", "automatic", "reminderAt=$reminderAt;responseMs=${(now - reminderAt).coerceAtLeast(0L)}")
        }
        Toast.makeText(this, "حان وقت الجلسة", Toast.LENGTH_LONG).show()
        intent.removeExtra("fromReminder")
    }


    private fun handleManualAlarmIntent(intent: Intent?) {
        if (intent?.getBooleanExtra("fromManualAlarm", false) != true) return
        showManualAlarmPage()
        intent.removeExtra("fromManualAlarm")
    }

    private fun buildShell() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        setContentView(root)

        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val scroll = ScrollView(this).apply { addView(content) }
        root.addView(scroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))

        val navScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(8, 6, 8, 10)
        }
        nav.addView(navButton("العدادات") { showCountersPage() })
        nav.addView(navButton("المنبه") { showTimerPage() })
        nav.addView(navButton("\u0645\u0646\u0628\u0647 \u064a\u062f\u0648\u064a") { showManualAlarmPage() })
        nav.addView(navButton("الجلسة الطويلة") { showLongSessionPage() })
        nav.addView(navButton("التقارير") { showReportsPage() })
        nav.addView(navButton("\u0627\u0644\u0625\u0639\u062f\u0627\u062f\u0627\u062a") { showSettingsPage() })
        navScroll.addView(nav)
        root.addView(navScroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
    }

    // ---------------- Counters ----------------
    private fun showCountersPage() {
        resetPageRefs()
        content.removeAllViews()
        addTitle("العدادات")
        addMuted("أربعة عدادات مستقلة — كل تغيير +1 أو -1 يُسجّل بوقته في التقارير")

        val grid = GridLayout(this).apply {
            columnCount = 2
            alignmentMode = GridLayout.ALIGN_MARGINS
            useDefaultMargins = true
        }
        counters.forEach { (key, label) ->
            grid.addView(counterCard(key, label), GridLayout.LayoutParams().apply {
                width = 0
                height = GridLayout.LayoutParams.WRAP_CONTENT
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                setMargins(6, 6, 6, 6)
            })
        }
        content.addView(grid, lp())

        addSection("ملخص اليوم")
        val today = EventStore.between(this, startOfToday(), startOfToday() + DAY)
        val reminders = today.count { it.optString("type") == "reminder" }
        val longEnds = today.filter { it.optString("type") == "long_end" }
        val activeMs = longEnds.sumOf { EventStore.metaMap(it.optString("meta"))["activeMs"]?.toLongOrNull() ?: 0L }
        addInfo("الرنات اليوم: $reminders")
        addInfo("وقت الجلسات الطويلة الفعلي: ${formatDuration(activeMs)}")
    }

    private fun counterCard(key: String, label: String): LinearLayout {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(14, 22, 14, 18)
            background = roundedBackground(0xFFF4F4F4.toInt())
        }
        card.addView(TextView(this).apply {
            text = label
            textSize = 20f
            setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER
        }, lp())
        val value = TextView(this).apply {
            text = Prefs.counter(this@MainActivity, key).toString()
            textSize = 42f
            setTypeface(Typeface.MONOSPACE, Typeface.BOLD)
            gravity = Gravity.CENTER
            setPadding(0, 10, 0, 10)
        }
        card.addView(value, lp())
        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        controls.addView(button("+1") {
            val newValue = Prefs.counter(this, key) + 1
            Prefs.setCounter(this, key, newValue)
            value.text = newValue.toString()
            EventStore.log(this, "counter_change", label, "key=$key;delta=1;value=$newValue")
        }, weightedLp())
        controls.addView(button("-1") {
            val newValue = (Prefs.counter(this, key) - 1).coerceAtLeast(0)
            Prefs.setCounter(this, key, newValue)
            value.text = newValue.toString()
            EventStore.log(this, "counter_change", label, "key=$key;delta=-1;value=$newValue")
        }, weightedLp())
        card.addView(controls, lp())
        return card
    }

    // ---------------- Automatic reminder ----------------
    private fun showTimerPage() {
        resetPageRefs()
        content.removeAllViews()
        addTitle("المنبه التلقائي")
        addMuted("صفحة مستقلة — يرن كل فترة تلقائيًا ويعيد نفسه باستمرار")

        remainingText = TextView(this).apply {
            textSize = 48f
            setTypeface(Typeface.MONOSPACE, Typeface.BOLD)
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 4)
        }
        content.addView(remainingText, lp())
        addMuted("المتبقي حتى الرنة القادمة")

        addSection("مدة التكرار")
        val preset = Spinner(this)
        val intervals = arrayOf("5", "10", "15", "30", "60")
        preset.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, intervals)
        preset.setSelection(intervals.indexOf(Prefs.intervalMinutes(this).toString()).let { if (it >= 0) it else 2 })
        content.addView(preset, lp())

        val custom = EditText(this).apply {
            hint = "أو اكتب عدد دقائق مخصص"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
        }
        content.addView(custom, lp())

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        row.addView(button("تشغيل دائم") {
            val interval = custom.text.toString().toIntOrNull()?.coerceAtLeast(1)
                ?: preset.selectedItem.toString().toInt()
            startAutomaticTimer(interval)
        }, weightedLp())
        row.addView(button("إيقاف") { stopAutomaticTimer() }, weightedLp())
        content.addView(row, lp())

        content.addView(button("السماح بالمنبه الدقيق") { openExactAlarmSettings() }, lp())
        addInfo("الفترة الحالية: كل ${Prefs.intervalMinutes(this)} دقيقة")
        addMuted("كل تشغيل، إيقاف، تغيير مدة، ورنة يتم تسجيله بوقت دقيق في صفحة التقارير.")
        addInfo("Ring: ${Prefs.ringDurationMs(this, "auto")} ms | ${Prefs.ringVolumePercent(this, "auto")}%")
        content.addView(button("\u0625\u0639\u062f\u0627\u062f\u0627\u062a \u0627\u0644\u0631\u0646\u0627\u062a") { showSettingsPage() }, lp())
        refreshLiveTimers()
    }

    private fun startAutomaticTimer(interval: Int) {
        val old = Prefs.intervalMinutes(this)
        if (old != interval) EventStore.log(this, "timer_change", "automatic", "old=$old;new=$interval")
        Prefs.setIntervalMinutes(this, interval)
        EventStore.log(this, "timer_start", "automatic", "interval=$interval")
        AlarmScheduler.scheduleNext(this, interval)
        Toast.makeText(this, "المنبه شغال تلقائيًا كل $interval دقيقة", Toast.LENGTH_SHORT).show()
        refreshLiveTimers()
    }

    private fun stopAutomaticTimer() {
        EventStore.log(this, "timer_stop", "automatic", "interval=${Prefs.intervalMinutes(this)}")
        AlarmScheduler.cancel(this)
        Toast.makeText(this, "تم إيقاف المنبه", Toast.LENGTH_SHORT).show()
        refreshLiveTimers()
    }

    // ---------------- Manual countdown alarm ----------------
    private fun showManualAlarmPage() {
        resetPageRefs()
        content.removeAllViews()
        addTitle("\u0627\u0644\u0645\u0646\u0628\u0647 \u0627\u0644\u064a\u062f\u0648\u064a")
        addMuted("\u0627\u0636\u0628\u0637 \u0645\u062f\u0629 \u0645\u062d\u062f\u062f\u0629. \u0628\u0639\u062f \u0627\u0644\u0627\u0646\u062a\u0647\u0627\u0621 \u064a\u0645\u0643\u0646 \u062a\u0643\u0631\u0627\u0631 \u062a\u0630\u0643\u064a\u0631\u0627\u062a \u062d\u062a\u0649 \u062a\u0631\u062c\u0639 \u0644\u0644\u062a\u0637\u0628\u064a\u0642.")

        if (Prefs.manualAwaitingReturn(this)) {
            ManualAlarmScheduler.acknowledge(this, "manual_page_opened")
            Toast.makeText(this, "\u062a\u0645 \u0625\u064a\u0642\u0627\u0641 \u062a\u0630\u0643\u064a\u0631\u0627\u062a \u0645\u0627 \u0628\u0639\u062f \u0627\u0644\u0627\u0646\u062a\u0647\u0627\u0621", Toast.LENGTH_SHORT).show()
        }

        manualTimerText = TextView(this).apply {
            textSize = 46f
            setTypeface(Typeface.MONOSPACE, Typeface.BOLD)
            gravity = Gravity.CENTER
            setPadding(0, 20, 0, 8)
        }
        content.addView(manualTimerText, lp())

        if (Prefs.manualRunning(this)) {
            addInfo("\u0627\u0644\u0645\u0646\u0628\u0647 \u0634\u063a\u0627\u0644 \u062d\u0627\u0644\u064a\u064b\u0627")
            content.addView(button("\u0625\u0644\u063a\u0627\u0621 \u0627\u0644\u0645\u0646\u0628\u0647") {
                EventStore.log(this, "manual_cancel", "manual", "targetAt=${Prefs.manualTargetAt(this)}")
                ManualAlarmScheduler.cancel(this)
                showManualAlarmPage()
            }, lp())
        } else {
            addSection("\u0627\u0644\u0645\u062f\u0629")
            val timeRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
            val hours = EditText(this).apply { hint = "h"; inputType = android.text.InputType.TYPE_CLASS_NUMBER; setText("0") }
            val minutes = EditText(this).apply { hint = "m"; inputType = android.text.InputType.TYPE_CLASS_NUMBER; setText("15") }
            val seconds = EditText(this).apply { hint = "s"; inputType = android.text.InputType.TYPE_CLASS_NUMBER; setText("0") }
            timeRow.addView(hours, weightedLp())
            timeRow.addView(minutes, weightedLp())
            timeRow.addView(seconds, weightedLp())
            content.addView(timeRow, lp())

            addSection("\u062a\u0630\u0643\u064a\u0631 \u0645\u0627 \u0628\u0639\u062f \u0627\u0644\u0627\u0646\u062a\u0647\u0627\u0621")
            val followSwitch = Switch(this).apply {
                text = "\u062a\u0643\u0631\u0627\u0631 \u0627\u0644\u062a\u0646\u0628\u064a\u0647 \u062d\u062a\u0649 \u0623\u0631\u062c\u0639 \u0644\u0644\u062a\u0637\u0628\u064a\u0642"
                isChecked = Prefs.followupEnabled(this@MainActivity)
            }
            content.addView(followSwitch, lp())
            val followMinutes = EditText(this).apply {
                hint = "\u0643\u0644 \u0643\u0627\u0645 \u062f\u0642\u064a\u0642\u0629\u061f"
                inputType = android.text.InputType.TYPE_CLASS_NUMBER
                setText(Prefs.followupMinutes(this@MainActivity).toString())
            }
            content.addView(followMinutes, lp())

            content.addView(button("\u0627\u0628\u062f\u0623 \u0627\u0644\u0645\u0646\u0628\u0647") {
                val h = hours.text.toString().toLongOrNull() ?: 0L
                val m = minutes.text.toString().toLongOrNull() ?: 0L
                val sec = seconds.text.toString().toLongOrNull() ?: 0L
                val totalMs = (h * 3_600_000L + m * 60_000L + sec * 1000L).coerceAtLeast(0L)
                if (totalMs < 1000L) {
                    Toast.makeText(this, "\u062d\u062f\u062f \u0645\u062f\u0629 \u0623\u0643\u0628\u0631 \u0645\u0646 \u0635\u0641\u0631", Toast.LENGTH_SHORT).show()
                    return@button
                }
                val follow = followSwitch.isChecked
                val repeatMin = (followMinutes.text.toString().toIntOrNull() ?: 5).coerceAtLeast(1)
                AlertDialog.Builder(this)
                    .setTitle("\u0647\u0644 \u0623\u0646\u062a \u0645\u062a\u0623\u0643\u062f\u061f")
                    .setMessage("\u0633\u064a\u0628\u062f\u0623 \u0627\u0644\u062a\u0627\u064a\u0645\u0631 \u0627\u0644\u0622\u0646. \u0627\u0644\u0645\u062f\u0629: ${formatClockHours(totalMs)}")
                    .setNegativeButton("\u0625\u0644\u063a\u0627\u0621", null)
                    .setPositiveButton("\u062a\u0623\u0643\u064a\u062f") { _, _ ->
                        Prefs.setFollowupEnabled(this, follow)
                        Prefs.setFollowupMinutes(this, repeatMin)
                        val target = System.currentTimeMillis() + totalMs
                        ManualAlarmScheduler.scheduleInitial(this, target)
                        EventStore.log(this, "manual_start", "manual", "durationMs=$totalMs;targetAt=$target;followup=${if (follow) 1 else 0};followupMin=$repeatMin")
                        Toast.makeText(this, "\u062a\u0645 \u062a\u0634\u063a\u064a\u0644 \u0627\u0644\u0645\u0646\u0628\u0647", Toast.LENGTH_SHORT).show()
                        showManualAlarmPage()
                    }
                    .show()
            }, lp())
        }

        addSection("\u0625\u0639\u062f\u0627\u062f\u0627\u062a \u0627\u0644\u0631\u0646\u0629")
        addInfo("\u0631\u0646\u0629 \u0627\u0644\u0627\u0646\u062a\u0647\u0627\u0621: ${Prefs.ringDurationMs(this, "manual")} ms | ${Prefs.ringVolumePercent(this, "manual")}%")
        addInfo("\u0631\u0646\u0629 \u0627\u0644\u0645\u062a\u0627\u0628\u0639\u0629: ${Prefs.ringDurationMs(this, "followup")} ms | ${Prefs.ringVolumePercent(this, "followup")}%")
        content.addView(button("\u0641\u062a\u062d \u0625\u0639\u062f\u0627\u062f\u0627\u062a \u0627\u0644\u0631\u0646\u0627\u062a") { showSettingsPage() }, lp())
        content.addView(button("\u0627\u0644\u0633\u0645\u0627\u062d \u0628\u0627\u0644\u0645\u0646\u0628\u0647 \u0627\u0644\u062f\u0642\u064a\u0642") { openExactAlarmSettings() }, lp())
        refreshLiveTimers()
    }

    // ---------------- Ring settings ----------------
    private fun showSettingsPage() {
        resetPageRefs()
        content.removeAllViews()
        addTitle("\u0625\u0639\u062f\u0627\u062f\u0627\u062a \u0627\u0644\u0631\u0646\u0627\u062a")
        addMuted("\u062a\u062d\u0643\u0645 \u0643\u0627\u0645\u0644 \u0641\u064a \u0627\u0644\u0635\u0648\u062a\u060c \u0627\u0644\u0627\u0647\u062a\u0632\u0627\u0632\u060c \u0637\u0648\u0644 \u0627\u0644\u0631\u0646\u0629 \u0648\u0642\u0648\u062a\u0647\u0627 \u0644\u0643\u0644 \u0646\u0648\u0639 \u0645\u0646 \u0627\u0644\u062a\u0646\u0628\u064a\u0647\u0627\u062a.")

        val master = Switch(this).apply { text = "\u0627\u0644\u0631\u0646\u0627\u062a \u0643\u0644\u0647\u0627 \u062a\u0634\u063a\u064a\u0644 / \u0625\u064a\u0642\u0627\u0641"; isChecked = Prefs.ringMasterEnabled(this@MainActivity) }
        val fullscreen = Switch(this).apply { text = "\u0634\u0627\u0634\u0629 \u062a\u0646\u0628\u064a\u0647 \u0643\u0627\u0645\u0644\u0629"; isChecked = Prefs.fullScreenRingEnabled(this@MainActivity) }
        val volumeMute = Switch(this).apply { text = "\u0632\u0631 \u0627\u0644\u0635\u0648\u062a \u064a\u0633\u0643\u062a \u0627\u0644\u0631\u0646\u0629 \u0627\u0644\u062d\u0627\u0644\u064a\u0629 \u0641\u0642\u0637"; isChecked = Prefs.volumeKeyMuteEnabled(this@MainActivity) }
        content.addView(master, lp())
        content.addView(fullscreen, lp())
        content.addView(volumeMute, lp())
        content.addView(button("\u062d\u0641\u0638 \u0627\u0644\u0625\u0639\u062f\u0627\u062f\u0627\u062a \u0627\u0644\u0639\u0627\u0645\u0629") {
            Prefs.setRingMasterEnabled(this, master.isChecked)
            Prefs.setFullScreenRingEnabled(this, fullscreen.isChecked)
            Prefs.setVolumeKeyMuteEnabled(this, volumeMute.isChecked)
            Toast.makeText(this, "\u062a\u0645 \u0627\u0644\u062d\u0641\u0638", Toast.LENGTH_SHORT).show()
        }, lp())
        content.addView(button("\u0635\u0644\u0627\u062d\u064a\u0629 \u0634\u0627\u0634\u0629 \u0627\u0644\u062a\u0646\u0628\u064a\u0647") { openFullScreenAlarmSettings() }, lp())

        addRingProfileEditor("auto", "\u0631\u0646\u0629 \u0627\u0644\u0645\u0646\u0628\u0647 \u0627\u0644\u062a\u0644\u0642\u0627\u0626\u064a")
        addRingProfileEditor("manual", "\u0631\u0646\u0629 \u0627\u0646\u062a\u0647\u0627\u0621 \u0627\u0644\u0645\u0646\u0628\u0647 \u0627\u0644\u064a\u062f\u0648\u064a")
        addRingProfileEditor("followup", "\u0631\u0646\u0629 \u062a\u0630\u0643\u064a\u0631 \u0645\u0627 \u0628\u0639\u062f \u0627\u0644\u0627\u0646\u062a\u0647\u0627\u0621")

        addSection("\u062a\u0630\u0643\u064a\u0631\u0627\u062a \u0645\u0627 \u0628\u0639\u062f \u0627\u0644\u0627\u0646\u062a\u0647\u0627\u0621")
        val follow = Switch(this).apply { text = "\u062a\u0634\u063a\u064a\u0644"; isChecked = Prefs.followupEnabled(this@MainActivity) }
        val followMin = EditText(this).apply { inputType = android.text.InputType.TYPE_CLASS_NUMBER; setText(Prefs.followupMinutes(this@MainActivity).toString()); hint = "Minutes" }
        content.addView(follow, lp())
        content.addView(followMin, lp())
        content.addView(button("\u062d\u0641\u0638 \u0625\u0639\u062f\u0627\u062f\u0627\u062a \u0627\u0644\u0645\u062a\u0627\u0628\u0639\u0629") {
            Prefs.setFollowupEnabled(this, follow.isChecked)
            Prefs.setFollowupMinutes(this, (followMin.text.toString().toIntOrNull() ?: 5).coerceAtLeast(1))
            if (!follow.isChecked) ManualAlarmScheduler.cancelFollowup(this)
            Toast.makeText(this, "\u062a\u0645 \u0627\u0644\u062d\u0641\u0638", Toast.LENGTH_SHORT).show()
        }, lp())
    }

    private fun addRingProfileEditor(type: String, label: String) {
        addSection(label)
        val sound = Switch(this).apply { text = "\u0627\u0644\u0635\u0648\u062a"; isChecked = Prefs.ringSoundEnabled(this@MainActivity, type) }
        val vibration = Switch(this).apply { text = "\u0627\u0644\u0627\u0647\u062a\u0632\u0627\u0632"; isChecked = Prefs.ringVibrationEnabled(this@MainActivity, type) }
        val duration = EditText(this).apply {
            hint = "Duration ms (100 - 30000)"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setText(Prefs.ringDurationMs(this@MainActivity, type).toString())
        }
        val volume = EditText(this).apply {
            hint = "Volume % (0 - 100)"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setText(Prefs.ringVolumePercent(this@MainActivity, type).toString())
        }
        content.addView(sound, lp())
        content.addView(vibration, lp())
        content.addView(duration, lp())
        content.addView(volume, lp())
        content.addView(button("\u062d\u0641\u0638 $label") {
            Prefs.setRingSoundEnabled(this, type, sound.isChecked)
            Prefs.setRingVibrationEnabled(this, type, vibration.isChecked)
            Prefs.setRingDurationMs(this, type, duration.text.toString().toLongOrNull() ?: 700L)
            Prefs.setRingVolumePercent(this, type, volume.text.toString().toIntOrNull() ?: 100)
            Toast.makeText(this, "\u062a\u0645 \u0627\u0644\u062d\u0641\u0638", Toast.LENGTH_SHORT).show()
        }, lp())
    }

    private fun openFullScreenAlarmSettings() {
        if (Build.VERSION.SDK_INT >= 34) {
            try {
                startActivity(Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse("package:$packageName")))
            } catch (_: Exception) {
                Toast.makeText(this, "\u0627\u0641\u062a\u062d \u0625\u0639\u062f\u0627\u062f\u0627\u062a \u0627\u0644\u062a\u0637\u0628\u064a\u0642 \u0648\u0641\u0639\u0651\u0644 \u062a\u0646\u0628\u064a\u0647\u0627\u062a \u0645\u0644\u0621 \u0627\u0644\u0634\u0627\u0634\u0629", Toast.LENGTH_LONG).show()
            }
        } else {
            Toast.makeText(this, "\u0647\u0630\u0647 \u0627\u0644\u0635\u0644\u0627\u062d\u064a\u0629 \u0644\u0627 \u062a\u062d\u062a\u0627\u062c \u0625\u0639\u062f\u0627\u062f\u064b\u0627 \u0645\u0646\u0641\u0635\u0644\u064b\u0627 \u0639\u0644\u0649 \u0647\u0630\u0627 \u0627\u0644\u0625\u0635\u062f\u0627\u0631", Toast.LENGTH_SHORT).show()
        }
    }

    // ---------------- Long & thinking sessions ----------------
    private fun showLongSessionPage() {
        resetPageRefs()
        content.removeAllViews()
        addTitle("عداد الجلسات الطويلة")
        addMuted("Stopwatch مستقل، والمنبه التلقائي يظل يعمل معه في نفس الوقت")

        longTimerText = TextView(this).apply {
            textSize = 46f
            setTypeface(Typeface.MONOSPACE, Typeface.BOLD)
            gravity = Gravity.CENTER
            setPadding(0, 20, 0, 8)
        }
        content.addView(longTimerText, lp())

        if (!Prefs.longRunning(this)) {
            val name = EditText(this).apply { hint = "اسم الجلسة — مثال: ICU Study" }
            val category = EditText(this).apply { hint = "التصنيف — مذاكرة / ألماني / عمل..." }
            content.addView(name, lp())
            content.addView(category, lp())
            content.addView(button("ابدأ جلسة طويلة") {
                val now = System.currentTimeMillis()
                val n = name.text.toString().trim().ifBlank { "جلسة طويلة" }
                val c = category.text.toString().trim().ifBlank { "عام" }
                Prefs.startLong(this, n, c, now)
                EventStore.log(this, "long_start", n, "category=$c", now)
                showLongSessionPage()
            }, lp())
        } else {
            addInfo("الجلسة: ${Prefs.longName(this)}")
            addInfo("التصنيف: ${Prefs.longCategory(this)}")
            val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
            if (Prefs.longPaused(this)) {
                controls.addView(button("استكمال") { resumeLongSession() }, weightedLp())
            } else {
                controls.addView(button("Pause") { pauseLongSession() }, weightedLp())
            }
            controls.addView(button("إنهاء") { finishLongSession() }, weightedLp())
            content.addView(controls, lp())
        }

        addSection("جلسة تفكير")
        thoughtTimerText = TextView(this).apply {
            textSize = 28f
            setTypeface(Typeface.MONOSPACE, Typeface.BOLD)
            gravity = Gravity.CENTER
        }
        content.addView(thoughtTimerText, lp())
        content.addView(button(if (Prefs.thoughtRunning(this)) "إنهاء جلسة التفكير" else "ابدأ جلسة تفكير") {
            toggleThoughtSession()
        }, lp())
        addMuted("جلسة التفكير تُسجل بوقت البداية والنهاية والمدة، وتظهر في التقارير.")
        refreshLiveTimers()
    }

    private fun pauseLongSession() {
        if (!Prefs.longRunning(this) || Prefs.longPaused(this)) return
        val now = System.currentTimeMillis()
        Prefs.pauseLong(this, now)
        EventStore.log(this, "long_pause", Prefs.longName(this), "category=${Prefs.longCategory(this)}", now)
        showLongSessionPage()
    }

    private fun resumeLongSession() {
        if (!Prefs.longRunning(this) || !Prefs.longPaused(this)) return
        val now = System.currentTimeMillis()
        val pausedAt = Prefs.longPausedAt(this)
        val pauseMs = (now - pausedAt).coerceAtLeast(0L)
        Prefs.resumeLong(this, now)
        EventStore.log(this, "long_resume", Prefs.longName(this), "category=${Prefs.longCategory(this)};pauseMs=$pauseMs", now)
        showLongSessionPage()
    }

    private fun finishLongSession() {
        if (!Prefs.longRunning(this)) return
        val now = System.currentTimeMillis()
        val start = Prefs.longStartAt(this)
        var pause = Prefs.longPausedTotal(this)
        if (Prefs.longPaused(this) && Prefs.longPausedAt(this) > 0L) pause += (now - Prefs.longPausedAt(this)).coerceAtLeast(0L)
        val total = (now - start).coerceAtLeast(0L)
        val active = (total - pause).coerceAtLeast(0L)
        val name = Prefs.longName(this)
        val category = Prefs.longCategory(this)
        EventStore.log(this, "long_end", name, "category=$category;totalMs=$total;activeMs=$active;pauseMs=$pause;startAt=$start", now)
        Prefs.clearLong(this)
        Toast.makeText(this, "تم حفظ الجلسة — وقت فعلي ${formatDuration(active)}", Toast.LENGTH_LONG).show()
        showLongSessionPage()
    }

    private fun toggleThoughtSession() {
        val now = System.currentTimeMillis()
        if (!Prefs.thoughtRunning(this)) {
            Prefs.startThought(this, now)
            EventStore.log(this, "thought_start", "جلسة تفكير", "insideLong=${if (Prefs.longRunning(this)) 1 else 0};longName=${Prefs.longName(this)}", now)
        } else {
            val start = Prefs.thoughtStartAt(this)
            val duration = (now - start).coerceAtLeast(0L)
            EventStore.log(this, "thought_end", "جلسة تفكير", "durationMs=$duration;startAt=$start;insideLong=${if (Prefs.longRunning(this)) 1 else 0};longName=${Prefs.longName(this)}", now)
            Prefs.clearThought(this)
        }
        showLongSessionPage()
    }

    // ---------------- Reports ----------------
    private fun showReportsPage() {
        resetPageRefs()
        content.removeAllViews()
        addTitle("التقارير والتحليلات")
        addMuted("كل مواعيد العدادات، الرنات، الزيادات والنقصان، الجلسات والتغييرات في Timeline واحد")

        val ranges = Spinner(this)
        val labels = arrayOf("اليوم", "آخر 7 أيام", "آخر 30 يوم", "كل السجل")
        ranges.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, labels)
        ranges.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) = Unit
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                val now = System.currentTimeMillis()
                when (position) {
                    0 -> { reportStart = startOfToday(); reportEnd = reportStart + DAY }
                    1 -> { reportStart = now - 7 * DAY; reportEnd = now + 1 }
                    2 -> { reportStart = now - 30 * DAY; reportEnd = now + 1 }
                    else -> { reportStart = 0L; reportEnd = Long.MAX_VALUE }
                }
                renderReport()
            }
        }
        content.addView(ranges, lp())

        val custom = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        custom.addView(button("من تاريخ") { pickReportDate(true) }, weightedLp())
        custom.addView(button("إلى تاريخ") { pickReportDate(false) }, weightedLp())
        content.addView(custom, lp())

        val export = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        export.addView(button("تصدير CSV") {
            ReportExporter.shareCsv(this, EventStore.between(this, reportStart, reportEnd))
        }, weightedLp())
        export.addView(button("تصدير PDF") {
            val events = EventStore.between(this, reportStart, reportEnd)
            ReportExporter.sharePdf(this, "Awareness Timer Report", reportSummaryLines(events), events)
        }, weightedLp())
        content.addView(export, lp())

        reportBody = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(reportBody, lp())
        renderReport()
    }

    private fun pickReportDate(isStart: Boolean) {
        val cal = Calendar.getInstance()
        val base = if (isStart && reportStart > 0L) reportStart else if (!isStart && reportEnd < Long.MAX_VALUE) reportEnd - 1 else System.currentTimeMillis()
        cal.timeInMillis = base
        DatePickerDialog(this, { _, y, m, d ->
            val chosen = Calendar.getInstance().apply {
                set(Calendar.YEAR, y); set(Calendar.MONTH, m); set(Calendar.DAY_OF_MONTH, d)
                set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            }.timeInMillis
            if (isStart) reportStart = chosen else reportEnd = chosen + DAY
            if (reportEnd <= reportStart) reportEnd = reportStart + DAY
            renderReport()
        }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
    }

    private fun renderReport() {
        val body = reportBody ?: return
        body.removeAllViews()
        val events = EventStore.between(this, reportStart, reportEnd)
        val sdf = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
        val rangeText = if (reportEnd == Long.MAX_VALUE) "كل السجل" else "${sdf.format(Date(reportStart))} → ${sdf.format(Date(reportEnd - 1))}"
        body.addView(sectionText("الفترة: $rangeText"), lp())

        reportSummaryLines(events).forEach { body.addView(infoText(it), lp()) }

        body.addView(sectionText("العدادات الأربعة — الحالة الحالية"), lp())
        counters.forEach { (key, label) -> body.addView(infoText("$label: ${Prefs.counter(this, key)}"), lp()) }

        body.addView(sectionText("Timeline"), lp())
        if (events.isEmpty()) {
            body.addView(infoText("لا توجد أحداث في هذه الفترة."), lp())
        } else {
            events.sortedByDescending { it.optLong("time") }.take(300).forEach { o ->
                body.addView(eventView(o), lp())
            }
            if (events.size > 300) body.addView(infoText("يظهر آخر 300 حدث هنا. التصدير يحتوي على كل الأحداث."), lp())
        }
    }

    private fun reportSummaryLines(events: List<JSONObject>): List<String> {
        val reminders = events.count { it.optString("type") == "reminder" }
        val opens = events.filter { it.optString("type") == "reminder_opened" }
        val responseValues = opens.mapNotNull { EventStore.metaMap(it.optString("meta"))["responseMs"]?.toLongOrNull() }
        val avgResponse = if (responseValues.isEmpty()) 0L else responseValues.average().roundToLong()
        val thoughtEnds = events.filter { it.optString("type") == "thought_end" }
        val thoughtMs = thoughtEnds.sumOf { EventStore.metaMap(it.optString("meta"))["durationMs"]?.toLongOrNull() ?: 0L }
        val longEnds = events.filter { it.optString("type") == "long_end" }
        val activeMs = longEnds.sumOf { EventStore.metaMap(it.optString("meta"))["activeMs"]?.toLongOrNull() ?: 0L }
        val pauseMs = longEnds.sumOf { EventStore.metaMap(it.optString("meta"))["pauseMs"]?.toLongOrNull() ?: 0L }
        val plus = events.count { it.optString("type") == "counter_change" && EventStore.metaMap(it.optString("meta"))["delta"] == "1" }
        val minus = events.count { it.optString("type") == "counter_change" && EventStore.metaMap(it.optString("meta"))["delta"] == "-1" }
        val responseRate = if (reminders == 0) 0 else (opens.size * 100 / reminders).coerceAtMost(100)
        val timerChanges = events.count { it.optString("type") == "timer_change" }
        val manualStarts = events.count { it.optString("type") == "manual_start" }
        val manualExpired = events.count { it.optString("type") == "manual_expired" }
        val followups = events.count { it.optString("type") == "manual_followup" }
        val mutedRings = events.count { it.optString("type") == "ring_muted" }

        return listOf(
            "الرنات: $reminders | تم فتحها: ${opens.size} | معدل الاستجابة: $responseRate%",
            "متوسط زمن الاستجابة: ${formatDuration(avgResponse)}",
            "جلسات التفكير المكتملة: ${thoughtEnds.size} | إجمالي التفكير: ${formatDuration(thoughtMs)}",
            "الجلسات الطويلة المكتملة: ${longEnds.size} | Active: ${formatDuration(activeMs)} | Pause: ${formatDuration(pauseMs)}",
            "عمليات +1: $plus | عمليات -1: $minus",
            "عدد تغييرات مدة المنبه: $timerChanges",
            "Manual timers: $manualStarts | expired: $manualExpired | follow-ups: $followups | muted current rings: $mutedRings"
        )
    }

    private fun eventView(o: JSONObject): TextView {
        val dt = SimpleDateFormat("dd/MM HH:mm:ss", Locale.getDefault()).format(Date(o.optLong("time")))
        val readable = when (o.optString("type")) {
            "counter_change" -> "تعديل عداد"
            "timer_start" -> "تشغيل المنبه"
            "timer_stop" -> "إيقاف المنبه"
            "timer_change" -> "تغيير مدة المنبه"
            "reminder" -> "رنة"
            "reminder_opened" -> "استجابة للرنة"
            "long_start" -> "بدء جلسة طويلة"
            "long_pause" -> "Pause جلسة طويلة"
            "long_resume" -> "استكمال جلسة طويلة"
            "long_end" -> "إنهاء جلسة طويلة"
            "thought_start" -> "بدء جلسة تفكير"
            "thought_end" -> "إنهاء جلسة تفكير"
            "manual_start" -> "Manual timer started"
            "manual_cancel" -> "Manual timer cancelled"
            "manual_expired" -> "Manual timer expired"
            "manual_followup" -> "Post-expiry reminder"
            "manual_ack" -> "Manual timer acknowledged"
            "ring_started" -> "Ring started"
            "ring_muted" -> "Current ring muted"
            else -> o.optString("type")
        }
        return TextView(this).apply {
            text = "$dt  •  $readable\n${o.optString("label")}  ${o.optString("meta")}"
            textSize = 14f
            setPadding(16, 12, 16, 12)
            background = roundedBackground(0xFFF7F7F7.toInt())
        }
    }

    // ---------------- Live timers & helpers ----------------
    private fun refreshLiveTimers() {
        remainingText?.let { tv ->
            if (!Prefs.timerRunning(this)) tv.text = "متوقف"
            else {
                val ms = (Prefs.nextAlarmAt(this) - System.currentTimeMillis()).coerceAtLeast(0L)
                tv.text = formatClock(ms)
            }
        }
        manualTimerText?.let { tv ->
            tv.text = when {
                Prefs.manualRunning(this) -> formatClockHours((Prefs.manualTargetAt(this) - System.currentTimeMillis()).coerceAtLeast(0L))
                Prefs.manualAwaitingReturn(this) -> "\u0627\u0646\u062a\u0647\u0649 - \u0628\u0627\u0646\u062a\u0638\u0627\u0631 \u0631\u062c\u0648\u0639\u0643"
                else -> "00:00:00"
            }
        }
        longTimerText?.let { tv ->
            if (!Prefs.longRunning(this)) tv.text = "00:00:00"
            else {
                val now = System.currentTimeMillis()
                val end = if (Prefs.longPaused(this)) Prefs.longPausedAt(this) else now
                val active = (end - Prefs.longStartAt(this) - Prefs.longPausedTotal(this)).coerceAtLeast(0L)
                tv.text = formatClockHours(active) + if (Prefs.longPaused(this)) "  ⏸" else ""
            }
        }
        thoughtTimerText?.let { tv ->
            tv.text = if (!Prefs.thoughtRunning(this)) "متوقفة" else "جاري التفكير: ${formatClockHours(System.currentTimeMillis() - Prefs.thoughtStartAt(this))}"
        }
    }

    private fun resetPageRefs() {
        remainingText = null
        manualTimerText = null
        longTimerText = null
        thoughtTimerText = null
        reportBody = null
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 99)
        }
    }

    private fun openExactAlarmSettings() {
        if (Build.VERSION.SDK_INT >= 31) {
            val am = getSystemService(ALARM_SERVICE) as AlarmManager
            if (!am.canScheduleExactAlarms()) startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName")))
            else Toast.makeText(this, "صلاحية المنبه الدقيق مفعلة", Toast.LENGTH_SHORT).show()
        } else Toast.makeText(this, "غير مطلوبة على إصدار Android الحالي", Toast.LENGTH_SHORT).show()
    }

    private fun roundedBackground(color: Int) = android.graphics.drawable.GradientDrawable().apply {
        setColor(color); cornerRadius = 24f; setStroke(1, 0x22000000)
    }

    private fun addTitle(textValue: String) { content.addView(TextView(this).apply {
        text = textValue; textSize = 28f; setTypeface(typeface, Typeface.BOLD); gravity = Gravity.CENTER; setPadding(0, 10, 0, 6)
    }, lp()) }

    private fun addSection(textValue: String) { content.addView(sectionText(textValue), lp()) }
    private fun addInfo(textValue: String) { content.addView(infoText(textValue), lp()) }
    private fun addMuted(textValue: String) { content.addView(TextView(this).apply {
        text = textValue; textSize = 14f; gravity = Gravity.CENTER; alpha = .65f; setPadding(0, 0, 0, 10)
    }, lp()) }

    private fun sectionText(textValue: String) = TextView(this).apply {
        text = textValue; textSize = 20f; setTypeface(typeface, Typeface.BOLD); setPadding(4, 18, 4, 4)
    }
    private fun infoText(textValue: String) = TextView(this).apply {
        text = textValue; textSize = 15f; setPadding(12, 8, 12, 8)
    }
    private fun button(textValue: String, onClick: () -> Unit) = Button(this).apply { text = textValue; setOnClickListener { onClick() } }
    private fun navButton(textValue: String, onClick: () -> Unit) = Button(this).apply { text = textValue; minWidth = 180; setOnClickListener { onClick() } }
    private fun lp() = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { setMargins(5, 6, 5, 6) }
    private fun weightedLp() = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(5, 4, 5, 4) }

    override fun onResume() {
        super.onResume()
        if (manualTimerText != null && Prefs.manualAwaitingReturn(this)) {
            ManualAlarmScheduler.acknowledge(this, "manual_page_resumed")
            showManualAlarmPage()
        }
    }

    override fun onDestroy() {
        handler.removeCallbacks(ticker)
        super.onDestroy()
    }

    companion object {
        private const val DAY = 86_400_000L
        private fun startOfToday(): Long = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }.timeInMillis

        private fun formatClock(ms: Long): String {
            val total = (ms / 1000).coerceAtLeast(0L)
            return "%02d:%02d".format(total / 60, total % 60)
        }

        private fun formatClockHours(ms: Long): String {
            val total = (ms / 1000).coerceAtLeast(0L)
            return "%02d:%02d:%02d".format(total / 3600, (total % 3600) / 60, total % 60)
        }

        private fun formatDuration(ms: Long): String {
            if (ms <= 0L) return "0m"
            val totalMin = ms / 60_000
            val h = totalMin / 60
            val m = totalMin % 60
            return if (h > 0) "${h}h ${m}m" else "${m}m"
        }
    }
}
