package com.zayed.awarenesstimer

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat

object RingNotifier {
    const val CHANNEL_ID = "ring_control_v1"
    const val NOTIFICATION_ID = 8801

    private fun ensureChannel(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channel = NotificationChannel(
            CHANNEL_ID,
            "Alarm and reminder alerts",
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = "Alarm notifications; sound is controlled by the app"
            setSound(null, null)
            enableVibration(false)
            setShowBadge(true)
        }
        nm.createNotificationChannel(channel)
    }

    fun build(context: Context, ringType: String, title: String, message: String, eventAt: Long, foreground: Boolean): Notification {
        ensureChannel(context)

        val openIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            if (ringType == "auto") {
                putExtra("fromReminder", true)
                putExtra("reminderAt", eventAt)
            } else {
                putExtra("fromManualAlarm", true)
                putExtra("manualRingAt", eventAt)
            }
        }
        val openPending = PendingIntent.getActivity(
            context,
            ((eventAt + 11) % Int.MAX_VALUE).toInt(),
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val fullIntent = Intent(context, RingActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra("ringType", ringType)
            putExtra("ringTitle", title)
            putExtra("ringMessage", message)
            putExtra("eventAt", eventAt)
        }
        val fullPending = PendingIntent.getActivity(
            context,
            ((eventAt + 23) % Int.MAX_VALUE).toInt(),
            fullIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = Intent(context, RingService::class.java).apply {
            action = RingService.ACTION_STOP_CURRENT
            putExtra("stopReason", "notification_button")
        }
        val stopPending = PendingIntent.getService(
            context,
            8802,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val builder = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(title)
            .setContentText(message)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setContentIntent(openPending)
            .setAutoCancel(!foreground)
            .setOngoing(foreground)
            .setSilent(true)
            .addAction(android.R.drawable.ic_lock_silent_mode_off, "Mute current ring", stopPending)

        if (Prefs.fullScreenRingEnabled(context)) {
            builder.setFullScreenIntent(fullPending, true)
        }
        return builder.build()
    }

    fun showAfterRing(context: Context, ringType: String, title: String, message: String, eventAt: Long) {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIFICATION_ID, build(context, ringType, title, message, eventAt, foreground = false))
    }
}
