package com.zayed.awarenesstimer

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (!Prefs.timerRunning(context)) return

        val interval = Prefs.intervalMinutes(context)
        val now = System.currentTimeMillis()
        Prefs.setLastReminderAt(context, now)
        val longMeta = if (Prefs.longRunning(context)) {
            ";insideLong=1;longName=${Prefs.longName(context)}"
        } else {
            ";insideLong=0"
        }
        EventStore.log(context, "reminder", "automatic", "interval=$interval$longMeta", now)

        showNotification(context, now)

        // Schedule the next reminder from this actual ring time. This keeps the
        // cycle running even when the UI is closed and avoids relying on an
        // in-app JavaScript/Handler timer.
        AlarmScheduler.scheduleNext(context, interval)
    }

    private fun showNotification(context: Context, reminderAt: Long) {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        // New ID is intentional: Android notification-channel sound settings are
        // immutable after creation. v4 guarantees that existing installs pick up
        // the new short custom sound rather than retaining the old default alarm.
        val channelId = "awareness_alarm_short_v4"
        val shortSound = Uri.parse("android.resource://${context.packageName}/${R.raw.awareness_beep}")

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val attrs = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()

            val channel = NotificationChannel(
                channelId,
                "رنة الوعي القصيرة",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "رنة قوية قصيرة لتذكيرك بأخذ الجلسة"
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 180, 80, 180)
                setSound(shortSound, attrs)
                setShowBadge(true)
            }
            nm.createNotificationChannel(channel)
        }

        val openIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or
                Intent.FLAG_ACTIVITY_CLEAR_TOP or
                Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra("fromReminder", true)
            putExtra("reminderAt", reminderAt)
        }
        val pendingOpen = PendingIntent.getActivity(
            context,
            (reminderAt % Int.MAX_VALUE).toInt(),
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("وقت الجلسة")
            .setContentText("خد جلستك دلوقتي.")
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setSound(shortSound)
            .setVibrate(longArrayOf(0, 180, 80, 180))
            .setAutoCancel(true)
            .setContentIntent(pendingOpen)
            .build()

        nm.notify((reminderAt % 100000).toInt(), notification)
    }
}
