package com.zayed.awarenesstimer

import android.content.Context
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object EventStore {
    private const val FILE = "events.jsonl"

    fun log(context: Context, type: String, label: String, meta: String = "", time: Long = System.currentTimeMillis()) {
        val o = JSONObject()
        o.put("time", time)
        o.put("type", type)
        o.put("label", label)
        o.put("meta", meta)
        File(context.filesDir, FILE).appendText(o.toString() + "\n")
    }

    fun all(context: Context): List<JSONObject> {
        val f = File(context.filesDir, FILE)
        if (!f.exists()) return emptyList()
        return f.readLines().mapNotNull {
            try { JSONObject(it) } catch (_: Exception) { null }
        }.sortedBy { it.optLong("time") }
    }

    fun between(context: Context, startInclusive: Long, endExclusive: Long): List<JSONObject> =
        all(context).filter { it.optLong("time") in startInclusive until endExclusive }

    fun csv(events: List<JSONObject>): String {
        val sb = StringBuilder("time_iso,type,label,meta\n")
        val iso = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
        events.forEach { o ->
            fun esc(s: String) = "\"" + s.replace("\"", "\"\"") + "\""
            sb.append(esc(iso.format(Date(o.optLong("time"))))).append(',')
                .append(esc(o.optString("type"))).append(',')
                .append(esc(o.optString("label"))).append(',')
                .append(esc(o.optString("meta"))).append('\n')
        }
        return sb.toString()
    }

    fun metaMap(meta: String): Map<String, String> = meta.split(';')
        .mapNotNull { part ->
            val i = part.indexOf('=')
            if (i <= 0) null else part.substring(0, i) to part.substring(i + 1)
        }.toMap()
}
