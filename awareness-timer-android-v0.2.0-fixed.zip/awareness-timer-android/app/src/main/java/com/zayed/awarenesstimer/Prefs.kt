package com.zayed.awarenesstimer

import android.content.Context

object Prefs {
    private const val NAME = "awareness_prefs"
    private fun p(c: Context) = c.getSharedPreferences(NAME, Context.MODE_PRIVATE)

    fun timerRunning(c: Context) = p(c).getBoolean("timerRunning", false)
    fun setTimerRunning(c: Context, v: Boolean) = p(c).edit().putBoolean("timerRunning", v).apply()

    fun intervalMinutes(c: Context) = p(c).getInt("intervalMinutes", 15)
    fun setIntervalMinutes(c: Context, v: Int) = p(c).edit().putInt("intervalMinutes", v.coerceAtLeast(1)).apply()

    fun nextAlarmAt(c: Context) = p(c).getLong("nextAlarmAt", 0L)
    fun setNextAlarmAt(c: Context, v: Long) = p(c).edit().putLong("nextAlarmAt", v).apply()

    fun lastReminderAt(c: Context) = p(c).getLong("lastReminderAt", 0L)
    fun setLastReminderAt(c: Context, v: Long) = p(c).edit().putLong("lastReminderAt", v).apply()

    fun counter(c: Context, key: String) = p(c).getInt("counter_$key", 0)
    fun setCounter(c: Context, key: String, value: Int) =
        p(c).edit().putInt("counter_$key", value.coerceAtLeast(0)).apply()

    // Shared ring controls.
    fun ringMasterEnabled(c: Context) = p(c).getBoolean("ring_master_enabled", true)
    fun setRingMasterEnabled(c: Context, v: Boolean) = p(c).edit().putBoolean("ring_master_enabled", v).apply()

    fun fullScreenRingEnabled(c: Context) = p(c).getBoolean("ring_fullscreen", true)
    fun setFullScreenRingEnabled(c: Context, v: Boolean) = p(c).edit().putBoolean("ring_fullscreen", v).apply()

    fun volumeKeyMuteEnabled(c: Context) = p(c).getBoolean("ring_volume_key_mute", true)
    fun setVolumeKeyMuteEnabled(c: Context, v: Boolean) = p(c).edit().putBoolean("ring_volume_key_mute", v).apply()

    fun ringSoundEnabled(c: Context, type: String) = p(c).getBoolean("ring_sound_$type", true)
    fun setRingSoundEnabled(c: Context, type: String, v: Boolean) = p(c).edit().putBoolean("ring_sound_$type", v).apply()

    fun ringVibrationEnabled(c: Context, type: String) = p(c).getBoolean("ring_vibration_$type", true)
    fun setRingVibrationEnabled(c: Context, type: String, v: Boolean) = p(c).edit().putBoolean("ring_vibration_$type", v).apply()

    fun ringDurationMs(c: Context, type: String): Long = p(c).getLong("ring_duration_$type", 700L).coerceIn(100L, 30_000L)
    fun setRingDurationMs(c: Context, type: String, v: Long) = p(c).edit().putLong("ring_duration_$type", v.coerceIn(100L, 30_000L)).apply()

    fun ringVolumePercent(c: Context, type: String): Int = p(c).getInt("ring_volume_$type", 100).coerceIn(0, 100)
    fun setRingVolumePercent(c: Context, type: String, v: Int) = p(c).edit().putInt("ring_volume_$type", v.coerceIn(0, 100)).apply()

    // Manual countdown alarm.
    fun manualRunning(c: Context) = p(c).getBoolean("manual_running", false)
    fun manualTargetAt(c: Context) = p(c).getLong("manual_target_at", 0L)
    fun manualAwaitingReturn(c: Context) = p(c).getBoolean("manual_awaiting_return", false)
    fun manualExpiredAt(c: Context) = p(c).getLong("manual_expired_at", 0L)
    fun followupEnabled(c: Context) = p(c).getBoolean("manual_followup_enabled", true)
    fun followupMinutes(c: Context) = p(c).getInt("manual_followup_minutes", 5).coerceAtLeast(1)

    fun setFollowupEnabled(c: Context, v: Boolean) = p(c).edit().putBoolean("manual_followup_enabled", v).apply()
    fun setFollowupMinutes(c: Context, v: Int) = p(c).edit().putInt("manual_followup_minutes", v.coerceAtLeast(1)).apply()

    fun startManual(c: Context, targetAt: Long) {
        p(c).edit()
            .putBoolean("manual_running", true)
            .putLong("manual_target_at", targetAt)
            .putBoolean("manual_awaiting_return", false)
            .putLong("manual_expired_at", 0L)
            .apply()
    }

    fun markManualExpired(c: Context, now: Long) {
        p(c).edit()
            .putBoolean("manual_running", false)
            .putBoolean("manual_awaiting_return", true)
            .putLong("manual_expired_at", now)
            .apply()
    }

    fun acknowledgeManual(c: Context) {
        p(c).edit()
            .putBoolean("manual_running", false)
            .putLong("manual_target_at", 0L)
            .putBoolean("manual_awaiting_return", false)
            .putLong("manual_expired_at", 0L)
            .apply()
    }

    fun clearManual(c: Context) = acknowledgeManual(c)

    // Long session stopwatch.
    fun longRunning(c: Context) = p(c).getBoolean("long_running", false)
    fun longPaused(c: Context) = p(c).getBoolean("long_paused", false)
    fun longStartAt(c: Context) = p(c).getLong("long_start_at", 0L)
    fun longPausedAt(c: Context) = p(c).getLong("long_paused_at", 0L)
    fun longPausedTotal(c: Context) = p(c).getLong("long_paused_total", 0L)
    fun longName(c: Context) = p(c).getString("long_name", "") ?: ""
    fun longCategory(c: Context) = p(c).getString("long_category", "") ?: ""

    fun startLong(c: Context, name: String, category: String, now: Long) {
        p(c).edit()
            .putBoolean("long_running", true)
            .putBoolean("long_paused", false)
            .putLong("long_start_at", now)
            .putLong("long_paused_at", 0L)
            .putLong("long_paused_total", 0L)
            .putString("long_name", name)
            .putString("long_category", category)
            .apply()
    }

    fun pauseLong(c: Context, now: Long) {
        p(c).edit().putBoolean("long_paused", true).putLong("long_paused_at", now).apply()
    }

    fun resumeLong(c: Context, now: Long) {
        val pausedAt = longPausedAt(c)
        val extra = if (pausedAt > 0L) (now - pausedAt).coerceAtLeast(0L) else 0L
        p(c).edit()
            .putBoolean("long_paused", false)
            .putLong("long_paused_at", 0L)
            .putLong("long_paused_total", longPausedTotal(c) + extra)
            .apply()
    }

    fun clearLong(c: Context) {
        p(c).edit()
            .putBoolean("long_running", false)
            .putBoolean("long_paused", false)
            .putLong("long_start_at", 0L)
            .putLong("long_paused_at", 0L)
            .putLong("long_paused_total", 0L)
            .putString("long_name", "")
            .putString("long_category", "")
            .apply()
    }

    fun thoughtRunning(c: Context) = p(c).getBoolean("thought_running", false)
    fun thoughtStartAt(c: Context) = p(c).getLong("thought_start_at", 0L)
    fun startThought(c: Context, now: Long) = p(c).edit().putBoolean("thought_running", true).putLong("thought_start_at", now).apply()
    fun clearThought(c: Context) = p(c).edit().putBoolean("thought_running", false).putLong("thought_start_at", 0L).apply()
}
