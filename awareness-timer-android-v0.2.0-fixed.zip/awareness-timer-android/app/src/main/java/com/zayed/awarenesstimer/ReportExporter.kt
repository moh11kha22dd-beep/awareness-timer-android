package com.zayed.awarenesstimer

import android.content.Context
import android.content.Intent
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object ReportExporter {
    private val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US)
    private val dateTime = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)

    fun shareCsv(context: Context, events: List<JSONObject>) {
        val file = File(context.cacheDir, "awareness_report_${stamp.format(Date())}.csv")
        file.writeText(EventStore.csv(events))
        share(context, file, "text/csv")
    }

    fun sharePdf(context: Context, title: String, summary: List<String>, events: List<JSONObject>) {
        val file = File(context.cacheDir, "awareness_report_${stamp.format(Date())}.pdf")
        val doc = PdfDocument()
        val paint = Paint().apply { textSize = 12f; isAntiAlias = true }
        val titlePaint = Paint().apply { textSize = 20f; isFakeBoldText = true; isAntiAlias = true }
        val pageW = 595
        val pageH = 842
        var pageNo = 1
        var page = doc.startPage(PdfDocument.PageInfo.Builder(pageW, pageH, pageNo).create())
        var canvas = page.canvas
        var y = 42f

        fun newPage() {
            doc.finishPage(page)
            pageNo++
            page = doc.startPage(PdfDocument.PageInfo.Builder(pageW, pageH, pageNo).create())
            canvas = page.canvas
            y = 42f
        }

        fun line(text: String, bold: Boolean = false) {
            if (y > pageH - 35) newPage()
            canvas.drawText(text.take(110), 28f, y, if (bold) titlePaint else paint)
            y += if (bold) 30f else 18f
        }

        line(title, true)
        summary.forEach { line(it) }
        y += 8f
        line("Timeline", true)
        events.sortedByDescending { it.optLong("time") }.forEach { o ->
            val text = "${dateTime.format(Date(o.optLong("time")))} | ${o.optString("type")} | ${o.optString("label")} | ${o.optString("meta")}" 
            line(text)
        }

        doc.finishPage(page)
        FileOutputStream(file).use { doc.writeTo(it) }
        doc.close()
        share(context, file, "application/pdf")
    }

    private fun share(context: Context, file: File, mime: String) {
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = mime
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "تصدير التقرير"))
    }
}
