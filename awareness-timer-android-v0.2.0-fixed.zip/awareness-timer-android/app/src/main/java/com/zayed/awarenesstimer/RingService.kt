package com.zayed.awarenesstimer

import android.app.Service
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioDeviceInfo
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.ToneGenerator
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.core.content.ContextCompat

class RingService : Service() {
    private var player: MediaPlayer? = null
    private var tone: ToneGenerator? = null
    private var vibrator: Vibrator? = null
    private val handler = Handler(Looper.getMainLooper())
    private var stopRunnable: Runnable? = null
    private var currentType: String = "auto"
    private var currentTitle: String = "Reminder"
    private var currentMessage: String = "Time for your reminder"
    private var currentEventAt: Long = 0L
    private var ringing = false
    private var wakeLock: PowerManager.WakeLock? = null
    private var audioManager: AudioManager? = null
    private var audioFocusRequest: AudioFocusRequest? = null
    private var previousAlarmVolume: Int? = null
    private var forcedAlarmVolume: Int? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP_CURRENT) {
            stopCurrent(intent.getStringExtra("stopReason") ?: "manual")
            return START_NOT_STICKY
        }

        currentType = intent?.getStringExtra("ringType") ?: "auto"
        currentTitle = intent?.getStringExtra("ringTitle") ?: "Reminder"
        currentMessage = intent?.getStringExtra("ringMessage") ?: "Time for your reminder"
        currentEventAt = intent?.getLongExtra("eventAt", System.currentTimeMillis()) ?: System.currentTimeMillis()

        startForeground(
            RingNotifier.NOTIFICATION_ID,
            RingNotifier.build(this, currentType, currentTitle, currentMessage, currentEventAt, foreground = true)
        )

        if (!Prefs.ringMasterEnabled(this)) {
            finishRing("master_disabled")
            return START_NOT_STICKY
        }

        startCurrentRing()
        return START_NOT_STICKY
    }

    private fun startCurrentRing() {
        stopPlaybackOnly(restoreVolume = true)
        ringing = true
        val duration = Prefs.ringDurationMs(this, currentType).coerceAtLeast(300L)
        val volumePercent = Prefs.ringVolumePercent(this, currentType).coerceIn(0, 100)

        acquireWakeLock(duration + 6000L)
        audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        requestAlarmAudioFocus()

        if (Prefs.ringSoundEnabled(this, currentType) && volumePercent > 0) {
            forceAlarmStreamVolume(volumePercent)
            val started = startMediaPlayer()
            if (!started) startToneFallback(volumePercent, duration)
        }

        if (Prefs.ringVibrationEnabled(this, currentType)) {
            vibrator = if (android.os.Build.VERSION.SDK_INT >= 31) {
                val vm = getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
                vm.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            }
            try {
                val pattern = longArrayOf(0, 180, 80, 180, 80, 180)
                vibrator?.vibrate(VibrationEffect.createWaveform(pattern, 0))
            } catch (_: Exception) { }
        }

        EventStore.log(
            this,
            "ring_started",
            currentType,
            "durationMs=$duration;volume=$volumePercent;tone=${Prefs.ringTone(this, currentType)};sound=${if (Prefs.ringSoundEnabled(this, currentType)) 1 else 0};vibration=${if (Prefs.ringVibrationEnabled(this, currentType)) 1 else 0};speaker=${if (Prefs.forcePhoneSpeakerEnabled(this)) 1 else 0}",
            currentEventAt
        )

        stopRunnable = Runnable { finishRing("duration_complete") }
        handler.postDelayed(stopRunnable!!, duration)
    }

    private fun acquireWakeLock(timeoutMs: Long) {
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "AwarenessTimer:RingWakeLock").apply {
                setReferenceCounted(false)
                acquire(timeoutMs)
            }
        } catch (_: Exception) { }
    }

    private fun requestAlarmAudioFocus() {
        val am = audioManager ?: return
        try {
            if (android.os.Build.VERSION.SDK_INT >= 26) {
                val attrs = AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
                audioFocusRequest = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                    .setAudioAttributes(attrs)
                    .setAcceptsDelayedFocusGain(false)
                    .build()
                am.requestAudioFocus(audioFocusRequest!!)
            } else {
                @Suppress("DEPRECATION")
                am.requestAudioFocus(null, AudioManager.STREAM_ALARM, AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
            }
        } catch (_: Exception) { }
    }

    private fun forceAlarmStreamVolume(percent: Int) {
        val am = audioManager ?: return
        try {
            val max = am.getStreamMaxVolume(AudioManager.STREAM_ALARM).coerceAtLeast(1)
            val old = am.getStreamVolume(AudioManager.STREAM_ALARM)
            val wanted = ((max * percent) / 100.0).toInt().coerceIn(1, max)
            previousAlarmVolume = old
            forcedAlarmVolume = wanted
            if (old != wanted) am.setStreamVolume(AudioManager.STREAM_ALARM, wanted, 0)
        } catch (_: Exception) { }
    }

    private fun selectedToneResource(): Int = when (Prefs.ringTone(this, currentType)) {
        2 -> R.raw.awareness_beep_2
        3 -> R.raw.awareness_beep_3
        4 -> R.raw.awareness_beep_4
        5 -> R.raw.awareness_beep_5
        else -> R.raw.awareness_beep
    }

    private fun startMediaPlayer(): Boolean {
        return try {
            val afd = resources.openRawResourceFd(selectedToneResource())
            val mp = MediaPlayer()
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            if (Prefs.forcePhoneSpeakerEnabled(this)) {
                try {
                    val am = audioManager
                    val speaker = am?.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
                        ?.firstOrNull { it.type == AudioDeviceInfo.TYPE_BUILTIN_SPEAKER }
                    if (speaker != null) mp.setPreferredDevice(speaker)
                } catch (_: Exception) { }
            }
            mp.setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
            afd.close()
            mp.isLooping = true
            // Stream volume is already set above. Keep player gain at full scale.
            mp.setVolume(1f, 1f)
            mp.prepare()
            mp.start()
            player = mp
            true
        } catch (_: Exception) {
            try { player?.release() } catch (_: Exception) { }
            player = null
            false
        }
    }

    private fun startToneFallback(volumePercent: Int, duration: Long) {
        try {
            tone = ToneGenerator(AudioManager.STREAM_ALARM, volumePercent.coerceIn(1, 100))
            tone?.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, duration.coerceAtMost(5000L).toInt())
        } catch (_: Exception) {
            tone?.release()
            tone = null
        }
    }

    private fun stopPlaybackOnly(restoreVolume: Boolean) {
        stopRunnable?.let { handler.removeCallbacks(it) }
        stopRunnable = null
        try { player?.stop() } catch (_: Exception) { }
        try { player?.release() } catch (_: Exception) { }
        player = null
        try { tone?.stopTone() } catch (_: Exception) { }
        try { tone?.release() } catch (_: Exception) { }
        tone = null
        try { vibrator?.cancel() } catch (_: Exception) { }
        vibrator = null
        if (restoreVolume) restoreAlarmVolume()
        abandonAudioFocus()
        try { if (wakeLock?.isHeld == true) wakeLock?.release() } catch (_: Exception) { }
        wakeLock = null
    }

    private fun restoreAlarmVolume() {
        val am = audioManager ?: return
        val old = previousAlarmVolume
        val forced = forcedAlarmVolume
        if (old != null && forced != null) {
            try {
                // Only restore if the user did not manually change alarm volume during the ring.
                if (am.getStreamVolume(AudioManager.STREAM_ALARM) == forced) {
                    am.setStreamVolume(AudioManager.STREAM_ALARM, old, 0)
                }
            } catch (_: Exception) { }
        }
        previousAlarmVolume = null
        forcedAlarmVolume = null
    }

    private fun abandonAudioFocus() {
        val am = audioManager ?: return
        try {
            if (android.os.Build.VERSION.SDK_INT >= 26) {
                audioFocusRequest?.let { am.abandonAudioFocusRequest(it) }
            } else {
                @Suppress("DEPRECATION")
                am.abandonAudioFocus(null)
            }
        } catch (_: Exception) { }
        audioFocusRequest = null
    }

    private fun stopCurrent(reason: String) {
        if (ringing) EventStore.log(this, "ring_muted", currentType, "reason=$reason")
        finishRing(reason)
    }

    private fun finishRing(reason: String) {
        stopPlaybackOnly(restoreVolume = true)
        ringing = false
        try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (_: Exception) { }
        RingNotifier.showAfterRing(this, currentType, currentTitle, currentMessage, currentEventAt)
        stopSelf()
    }

    override fun onDestroy() {
        stopPlaybackOnly(restoreVolume = true)
        super.onDestroy()
    }

    companion object {
        const val ACTION_START = "com.zayed.awarenesstimer.START_RING"
        const val ACTION_STOP_CURRENT = "com.zayed.awarenesstimer.STOP_CURRENT_RING"

        fun start(context: Context, ringType: String, title: String, message: String, eventAt: Long) {
            val i = Intent(context, RingService::class.java).apply {
                action = ACTION_START
                putExtra("ringType", ringType)
                putExtra("ringTitle", title)
                putExtra("ringMessage", message)
                putExtra("eventAt", eventAt)
            }
            ContextCompat.startForegroundService(context, i)
        }

        fun stopCurrent(context: Context, reason: String) {
            val i = Intent(context, RingService::class.java).apply {
                action = ACTION_STOP_CURRENT
                putExtra("stopReason", reason)
            }
            try { context.startService(i) } catch (_: Exception) { context.stopService(Intent(context, RingService::class.java)) }
        }
    }
}
