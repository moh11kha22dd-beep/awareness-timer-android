package com.zayed.awarenesstimer

import android.app.Service
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.core.content.ContextCompat

class RingService : Service() {
    private var player: MediaPlayer? = null
    private var vibrator: Vibrator? = null
    private val handler = Handler(Looper.getMainLooper())
    private var stopRunnable: Runnable? = null
    private var currentType: String = "auto"
    private var currentTitle: String = "Reminder"
    private var currentMessage: String = "Time for your reminder"
    private var currentEventAt: Long = 0L
    private var ringing = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP_CURRENT) {
            stopCurrent(intent.getStringExtra("stopReason") ?: "manual")
            return START_NOT_STICKY
        }

        currentType = intent?.getStringExtra("ringType") ?: "auto"
        currentTitle = intent?.getStringExtra("ringTitle") ?: "Reminder"
        currentMessage = intent?.getStringExtra("ringMessage") ?: "Time for your reminder"
        currentEventAt = intent?.getLongExtra("eventAt", System.currentTimeMillis()) ?: System.currentTimeMillis()

        startForeground(
            RingNotifier.NOTIFICATION_ID,
            RingNotifier.build(this, currentType, currentTitle, currentMessage, currentEventAt, foreground = true)
        )

        if (!Prefs.ringMasterEnabled(this)) {
            finishRing("master_disabled")
            return START_NOT_STICKY
        }

        startCurrentRing()
        return START_NOT_STICKY
    }

    private fun startCurrentRing() {
        stopPlaybackOnly()
        ringing = true
        val duration = Prefs.ringDurationMs(this, currentType)
        val volume = Prefs.ringVolumePercent(this, currentType).coerceIn(0, 100) / 100f

        if (Prefs.ringSoundEnabled(this, currentType) && volume > 0f) {
            try {
                val afd = resources.openRawResourceFd(R.raw.awareness_beep)
                player = MediaPlayer().apply {
                    setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_ALARM)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()
                    )
                    setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
                    isLooping = true
                    setVolume(volume, volume)
                    prepare()
                    start()
                }
                afd.close()
            } catch (_: Exception) {
                player?.release()
                player = null
            }
        }

        if (Prefs.ringVibrationEnabled(this, currentType)) {
            vibrator = if (android.os.Build.VERSION.SDK_INT >= 31) {
                val vm = getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
                vm.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            }
            try {
                vibrator?.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 150, 100, 150), 0))
            } catch (_: Exception) { }
        }

        EventStore.log(
            this,
            "ring_started",
            currentType,
            "durationMs=$duration;volume=${Prefs.ringVolumePercent(this, currentType)};sound=${if (Prefs.ringSoundEnabled(this, currentType)) 1 else 0};vibration=${if (Prefs.ringVibrationEnabled(this, currentType)) 1 else 0}",
            currentEventAt
        )

        stopRunnable = Runnable { finishRing("duration_complete") }
        handler.postDelayed(stopRunnable!!, duration)
    }

    private fun stopPlaybackOnly() {
        stopRunnable?.let { handler.removeCallbacks(it) }
        stopRunnable = null
        try { player?.stop() } catch (_: Exception) { }
        player?.release()
        player = null
        try { vibrator?.cancel() } catch (_: Exception) { }
        vibrator = null
    }

    private fun stopCurrent(reason: String) {
        if (ringing) {
            EventStore.log(this, "ring_muted", currentType, "reason=$reason")
        }
        finishRing(reason)
    }

    private fun finishRing(reason: String) {
        stopPlaybackOnly()
        ringing = false
        try {
            stopForeground(STOP_FOREGROUND_REMOVE)
        } catch (_: Exception) { }
        RingNotifier.showAfterRing(this, currentType, currentTitle, currentMessage, currentEventAt)
        stopSelf()
    }

    override fun onDestroy() {
        stopPlaybackOnly()
        super.onDestroy()
    }

    companion object {
        const val ACTION_START = "com.zayed.awarenesstimer.START_RING"
        const val ACTION_STOP_CURRENT = "com.zayed.awarenesstimer.STOP_CURRENT_RING"

        fun start(context: Context, ringType: String, title: String, message: String, eventAt: Long) {
            val i = Intent(context, RingService::class.java).apply {
                action = ACTION_START
                putExtra("ringType", ringType)
                putExtra("ringTitle", title)
                putExtra("ringMessage", message)
                putExtra("eventAt", eventAt)
            }
            ContextCompat.startForegroundService(context, i)
        }

        fun stopCurrent(context: Context, reason: String) {
            val i = Intent(context, RingService::class.java).apply {
                action = ACTION_STOP_CURRENT
                putExtra("stopReason", reason)
            }
            try {
                context.startService(i)
            } catch (_: Exception) {
                context.stopService(Intent(context, RingService::class.java))
            }
        }
    }
}
