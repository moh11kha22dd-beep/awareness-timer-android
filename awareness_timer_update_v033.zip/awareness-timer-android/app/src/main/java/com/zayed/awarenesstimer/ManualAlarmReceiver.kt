package com.zayed.awarenesstimer

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class ManualAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val phase = intent?.getStringExtra("phase") ?: "initial"
        val now = System.currentTimeMillis()

        if (phase == "initial") {
            if (!Prefs.manualRunning(context)) return
            Prefs.markManualExpired(context, now)
            EventStore.log(context, "manual_expired", "manual", "targetAt=${Prefs.manualTargetAt(context)}", now)
            RingService.start(
                context,
                "manual",
                "\u0627\u0644\u0645\u0646\u0628\u0647 \u0627\u0646\u062a\u0647\u0649",
                "\u0627\u0631\u062c\u0639 \u0644\u0644\u062a\u0637\u0628\u064a\u0642 \u0644\u062a\u0623\u0643\u064a\u062f \u0627\u0646\u062a\u0647\u0627\u0621 \u0627\u0644\u062a\u0627\u064a\u0645\u0631.",
                now
            )
            ManualAlarmScheduler.scheduleFollowup(context)
            return
        }

        if (phase == "followup") {
            if (!Prefs.manualAwaitingReturn(context) || !Prefs.followupEnabled(context)) return
            EventStore.log(context, "manual_followup", "manual", "interval=${Prefs.followupMinutes(context)}", now)
            RingService.start(
                context,
                "followup",
                "\u062a\u0630\u0643\u064a\u0631 \u0628\u0627\u0644\u0645\u0646\u0628\u0647",
                "\u0644\u0633\u0647 \u0645\u0627 \u0631\u062c\u0639\u062a\u0634 \u0644\u0644\u062a\u0637\u0628\u064a\u0642. \u0627\u0641\u062a\u062d\u0647 \u0644\u0625\u064a\u0642\u0627\u0641 \u062a\u0630\u0643\u064a\u0631\u0627\u062a \u0645\u0627 \u0628\u0639\u062f \u0627\u0644\u0627\u0646\u062a\u0647\u0627\u0621.",
                now
            )
            ManualAlarmScheduler.scheduleFollowup(context)
        }
    }
}
