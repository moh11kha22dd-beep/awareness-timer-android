package com.zayed.awarenesstimer

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action != Intent.ACTION_BOOT_COMPLETED) return

        if (Prefs.timerRunning(context)) {
            AlarmScheduler.scheduleNext(context, Prefs.intervalMinutes(context))
            EventStore.log(context, "system", "auto_rescheduled_after_boot")
        }
        if (Prefs.manualRunning(context) || Prefs.manualAwaitingReturn(context)) {
            ManualAlarmScheduler.restoreAfterBoot(context)
            EventStore.log(context, "system", "manual_rescheduled_after_boot")
        }
    }
}
