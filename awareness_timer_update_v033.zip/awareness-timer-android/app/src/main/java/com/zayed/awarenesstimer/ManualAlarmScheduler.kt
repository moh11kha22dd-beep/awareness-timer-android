package com.zayed.awarenesstimer

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build

object ManualAlarmScheduler {
    private const val REQ_INITIAL = 7021
    private const val REQ_FOLLOWUP = 7022

    fun scheduleInitial(context: Context, targetAt: Long) {
        Prefs.startManual(context, targetAt)
        schedule(context, targetAt, REQ_INITIAL, "initial")
    }

    fun scheduleFollowup(context: Context, delayMinutes: Int = Prefs.followupMinutes(context)) {
        if (!Prefs.followupEnabled(context) || !Prefs.manualAwaitingReturn(context)) return
        val trigger = System.currentTimeMillis() + delayMinutes.coerceAtLeast(1) * 60_000L
        schedule(context, trigger, REQ_FOLLOWUP, "followup")
    }

    private fun schedule(context: Context, trigger: Long, requestCode: Int, phase: String) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = PendingIntent.getBroadcast(
            context,
            requestCode,
            Intent(context, ManualAlarmReceiver::class.java).putExtra("phase", phase),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pi)
        } else {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pi)
        }
    }

    // The manual alarm is acknowledged ONLY by an explicit user action inside the app.
    // Merely opening the page or muting a burst must never call this function.
    fun acknowledge(context: Context, source: String = "explicit_stop_button") {
        if (Prefs.manualAwaitingReturn(context)) {
            EventStore.log(context, "manual_ack", "manual", "source=$source;expiredAt=${Prefs.manualExpiredAt(context)}")
        }
        cancelFollowup(context)
        Prefs.acknowledgeManual(context)
        RingService.stopCurrent(context, "manual_ack:$source")
        RingNotifier.cancel(context)
    }

    fun cancel(context: Context) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(pending(context, REQ_INITIAL, "initial"))
        am.cancel(pending(context, REQ_FOLLOWUP, "followup"))
        Prefs.clearManual(context)
        RingService.stopCurrent(context, "manual_cancel")
        RingNotifier.cancel(context)
    }

    fun cancelFollowup(context: Context) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(pending(context, REQ_FOLLOWUP, "followup"))
    }

    private fun pending(context: Context, requestCode: Int, phase: String): PendingIntent = PendingIntent.getBroadcast(
        context,
        requestCode,
        Intent(context, ManualAlarmReceiver::class.java).putExtra("phase", phase),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    fun restoreAfterBoot(context: Context) {
        if (Prefs.manualRunning(context)) {
            val target = Prefs.manualTargetAt(context)
            val trigger = if (target > System.currentTimeMillis()) target else System.currentTimeMillis() + 1500L
            schedule(context, trigger, REQ_INITIAL, "initial")
        } else if (Prefs.manualAwaitingReturn(context)) {
            // Restore the alarm immediately after boot, then keep the configured follow-up
            // as a watchdog in case Android kills the foreground service later.
            RingService.start(
                context,
                "followup",
                "المنبه ما زال نشطًا",
                "افتح التطبيق واضغط إيقاف المنبه وإنهاؤه.",
                System.currentTimeMillis()
            )
            if (Prefs.followupEnabled(context)) scheduleFollowup(context)
        }
    }
}
