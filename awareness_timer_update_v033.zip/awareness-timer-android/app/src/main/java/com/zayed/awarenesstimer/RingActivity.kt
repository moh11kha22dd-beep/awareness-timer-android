package com.zayed.awarenesstimer

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.KeyEvent
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class RingActivity : AppCompatActivity() {
    private var ringType: String = "auto"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
            )
        }
        window.addFlags(
            WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or
                WindowManager.LayoutParams.FLAG_ALLOW_LOCK_WHILE_SCREEN_ON
        )

        ringType = intent.getStringExtra("ringType") ?: "auto"
        val title = intent.getStringExtra("ringTitle") ?: "Reminder"
        val message = intent.getStringExtra("ringMessage") ?: ""
        val manualActive = ringType != "auto" && Prefs.manualAwaitingReturn(this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(40, 60, 40, 60)
        }
        root.addView(TextView(this).apply {
            text = title
            textSize = 30f
            gravity = Gravity.CENTER
        })
        root.addView(TextView(this).apply {
            text = if (manualActive) "$message\n\nالمنبه ما زال نشطًا. فتح التطبيق أو إسكات الصوت لا يُنهيه." else message
            textSize = 18f
            gravity = Gravity.CENTER
            setPadding(0, 20, 0, 30)
        })
        root.addView(Button(this).apply {
            text = "إسكات الرنة الحالية فقط"
            setOnClickListener {
                RingService.muteCurrent(this@RingActivity, "screen_button")
                finish()
            }
        })
        root.addView(Button(this).apply {
            text = if (manualActive) "فتح التطبيق لإيقاف المنبه" else "فتح التطبيق"
            setOnClickListener {
                val i = Intent(this@RingActivity, MainActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
                    if (ringType == "auto") putExtra("fromReminder", true) else putExtra("fromManualAlarm", true)
                    putExtra("reminderAt", intent.getLongExtra("eventAt", System.currentTimeMillis()))
                }
                startActivity(i)
                finish()
            }
        })
        setContentView(root)
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (Prefs.volumeKeyMuteEnabled(this) && (keyCode == KeyEvent.KEYCODE_VOLUME_UP || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN || keyCode == KeyEvent.KEYCODE_VOLUME_MUTE)) {
            RingService.muteCurrent(this, "volume_key")
            finish()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }
}
