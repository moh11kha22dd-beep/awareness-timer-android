package com.zayed.awarenesstimer

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (!Prefs.timerRunning(context)) return

        val interval = Prefs.intervalMinutes(context)
        val now = System.currentTimeMillis()
        Prefs.setLastReminderAt(context, now)
        val longMeta = if (Prefs.longRunning(context)) {
            ";insideLong=1;longName=${Prefs.longName(context)}"
        } else {
            ";insideLong=0"
        }
        EventStore.log(context, "reminder", "automatic", "interval=$interval$longMeta", now)

        RingService.start(
            context,
            "auto",
            "\u0648\u0642\u062a \u0627\u0644\u062c\u0644\u0633\u0629",
            "\u062e\u062f \u062c\u0644\u0633\u062a\u0643 \u062f\u0644\u0648\u0642\u062a\u064a.",
            now
        )

        // Schedule the next reminder from the actual ring time.
        AlarmScheduler.scheduleNext(context, interval)
    }
}
